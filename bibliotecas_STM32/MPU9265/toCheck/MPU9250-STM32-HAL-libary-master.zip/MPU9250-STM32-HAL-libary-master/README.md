# MPU9250-STM32-HAL-libary
C library for STM32 using HAL with SPI and I2C support
