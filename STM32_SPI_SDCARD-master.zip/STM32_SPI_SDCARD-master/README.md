# STM32_SPI_SDCARD
STM32 FatFS + SD Card Example via SPI interface

https://blog.naver.com/eziya76/221188701172

Reference : 
 - https://blog.domski.pl/using-fatfs-with-hal/
 - http://elm-chan.org/docs/mmc/mmc_e.html
 - http://www.dejazzer.com/ee379/lecture_notes/lec12_sd_card.pdf
